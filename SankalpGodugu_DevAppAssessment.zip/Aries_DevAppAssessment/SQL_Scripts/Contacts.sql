﻿CREATE TABLE [dbo].[Contacts] (
    [StudentId]    INT          NOT NULL,
    [LastName]     VARCHAR (50) NULL,
    [FirstName]    VARCHAR (50) NULL,
    [Relationship]  VARCHAR (50) NULL,
    [EmailAddress] VARCHAR (50) NULL,
    [Mobile]        VARCHAR (50) NULL,
    [Address]       VARCHAR (50) NULL,
    [City]          VARCHAR (50) NULL,
    [State]         VARCHAR NULL,
    [ZipCode]      VARCHAR (50) NULL
);

INSERT INTO studentcontacts VALUES
	(99400001, 'Abbot', 'Sara', 'Mother', 'sara@example.com', '949-123-45678', '1118 Glenview Lane', 'Eagle Rock', 'CA', 99999),
	(99400001, 'Abbot', 'Adam', 'Father', 'adam@example.com', '949-123-45679', '1118 Glenview Lane', 'Eagle Rock', 'CA', 99999),
	(99400011, 'Abrahamson', 'Jonathan', 'Uncle', 'jonathan@example.com', '949-234-4567', '1126 E Walton Rd.', 'Eagle Rock', 'CA', 99999),
	(99400012, 'Acosta', 'Christine', 'Mother', 'christine@example.com', '949-345-6789', '115 W Norgate St', 'Eagle Rock', 'CA', 99999),
	(99400013, 'Abrego', 'Rezvan', 'Father', 'rezvan@example.com', '949-456-7891', '13642 Green Valley B', 'Eagle Rock', 'CA', 99999),
	(99400014, 'AbuJohn', 'Selina', 'Mother', 'selina@example.com', '949-567-8912', '1123 N Barston Ave', 'Eagle Rock', 'CA', 99999),
	(99400015, 'Aceves', 'Jacob', 'Father', 'jacob@example.com', '949-678-9123', '1110 Avenida Loma Vista', 'Eagle Rock', 'CA', 99999);