﻿using Dapper;
using MyWebApi.Models;
using MyWebAPI.Context;
using MyWebApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyWebAPI.Repository
{
    public class StudentRepository : IStudentRepository
    {
        DapperContext _context;

        public StudentRepository(DapperContext context)
        {
            _context = context;
        }

        /// <summary>
        /// queries db for list of students
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Student>> GetStudents()
        {
            var query = "SELECT * FROM Students";

            using (var conn = _context.CreateConnection())
            {
                var students = await conn.QueryAsync<Student>(query);
                return students;
            }
        }

        public async Task<IEnumerable<Contact>> GetStudentContacts(int studentId)
        {
            var query = "SELECT * FROM Contacts WHERE StudentId = " + studentId;

            using (var conn = _context.CreateConnection())
            {
                var contacts = await conn.QueryAsync<Contact>(query);
                return contacts;
            }
        }
    }
}
