﻿using System.Collections.Generic;
using System.ComponentModel;

namespace MyWebApp.Models
{
    public class Student
    {
        [DisplayName("School Code")]
        public string SchoolCode { get; set; }

        [DisplayName("Student Id")]
        public int StudentId { get; set; }

        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("First Name")]
        public string FirstName { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        [DisplayName("Zip Code")]
        public string ZipCode { get; set; }

        public IEnumerable<Contact> Contacts { get; set; }
    }
}
