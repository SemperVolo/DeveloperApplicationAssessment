﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyWebApp.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace MyWebApp.Controllers
{
    public class StudentsController : Controller
    {
        private readonly ILogger<StudentsController> _logger;
        private readonly IHttpClientFactory _clientFactory;
        private readonly HttpClient client;

        public StudentsController(ILogger<StudentsController> logger, IHttpClientFactory clientFactory)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            client = _clientFactory.CreateClient();
            client.BaseAddress = new Uri("https://localhost:44347/");
        }

        public async Task<IActionResult> Index()
        {
            var students = await GetStudentsFromAPI();
            return View(students);
        }

        public async Task<IEnumerable<Student>> GetStudentsFromAPI()
        {
            try
            {
                var response = await client.GetAsync("/api/students");
                return await response.Content.ReadAsAsync<IEnumerable<Student>>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return new List<Student>();
        }

        public async Task<IActionResult> GetStudentContactsFromAPI(int studentId)
        {
            try
            {
                var response = await client.GetAsync("/api/students/" + studentId + "/contacts");
                return Json(await response.Content.ReadAsAsync<IEnumerable<Contact>>());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Json(new List<Contact>());
        }
    }
}
