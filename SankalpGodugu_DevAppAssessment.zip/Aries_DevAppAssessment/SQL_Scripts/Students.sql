﻿CREATE TABLE [dbo].[Students]
(
	[SchoolCode] INT NOT NULL, 
    [StudentId] INT NOT NULL, 
    [LastName] VARCHAR(50) NULL, 
    [FirstName] VARCHAR(50) NULL, 
    [Address] VARCHAR(50) NULL, 
    [City] VARCHAR(50) NULL, 
    [State] VARCHAR(50) NULL, 
    [ZipCode] VARCHAR NULL, 
    PRIMARY KEY ([StudentId])
);

INSERT INTO Students VALUES
	(994, 99400001, 'Abbot', 'Allan', '1118 Glenview Lane', 'Eagle Rock', 'CA', 99999),
	(994, 99400011, 'Abrahamson', 'Arnold', '1126 E Walton Rd.', 'Eagle Rock', 'CA', 99999),
	(994, 99400012, 'Abrego', 'Alice', '115 W Norgate St', 'Eagle Rock', 'CA', 99999),
	(994, 9940001, 'Abrego', 'Ivette', '13642 Green Valley B', 'Eagle Rock', 'CA', 99999),
	(994, 9940001, 'AbuJohn', 'Edgar', '1123 N Barston Ave', 'Eagle Rock', 'CA', 99999),
	(994, 9940001, 'Aceves', 'Steven', '1110 Avenida LomaVista', 'Eagle Rock', 'CA', 99999);