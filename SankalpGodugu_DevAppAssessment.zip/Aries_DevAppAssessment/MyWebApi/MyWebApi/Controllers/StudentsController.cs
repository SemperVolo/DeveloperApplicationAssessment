﻿using Microsoft.AspNetCore.Mvc;
using MyWebAPI.Repository;
using System;
using System.Threading.Tasks;

namespace MyWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        IStudentRepository _repo;

        public StudentsController(IStudentRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public async Task<IActionResult> GetStudents()
        {
            try
            {
                var students = await _repo.GetStudents();
                return Ok(students);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("{studentId}/contacts")]
        public async Task<IActionResult> GetStudentContacts(int studentId)
        {
            try
            {
                var contacts = await _repo.GetStudentContacts(studentId);
                return Ok(contacts);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
