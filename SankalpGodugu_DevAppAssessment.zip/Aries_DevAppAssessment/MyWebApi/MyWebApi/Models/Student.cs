﻿using MyWebApi.Models;
using System.Collections.Generic;

namespace MyWebApp.Models
{
    public class Student
    {
        public string SchoolCode { get; set; }
        public int StudentId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public IEnumerable<Contact> Contacts { get; set; }
    }
}
