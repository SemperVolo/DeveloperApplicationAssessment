﻿using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace MyWebAPI.Context
{
    public class DapperContext
    {
        private readonly IConfiguration _config; // inject this interface to allow for accessing connection string from appsettings
        private readonly string _connectionString;

        public DapperContext(IConfiguration config)
        {
            _config = config;
            _connectionString = _config.GetConnectionString("SqlConnection");
        }

        /// <summary>
        /// creates new SqlConnection object
        /// </summary>
        /// <returns></returns>
        public IDbConnection CreateConnection() => new SqlConnection(_connectionString);
    }
}
