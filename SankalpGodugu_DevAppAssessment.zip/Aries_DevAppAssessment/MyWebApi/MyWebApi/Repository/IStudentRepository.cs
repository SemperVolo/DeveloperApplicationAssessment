﻿using MyWebApi.Models;
using MyWebApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyWebAPI.Repository
{
    public interface IStudentRepository
    {
        public Task<IEnumerable<Student>> GetStudents();
        public Task<IEnumerable<Contact>> GetStudentContacts(int studentId);
    }
}
